let ALL=document.querySelector("#ALL")
let Search=document.querySelector("#Search")
let div=document.querySelector("#div")
let input=document.querySelector("#input")

$.get("https://restcountries.eu/rest/v2/all?fields=name;capital;currencies;topLevelDomain;flag", function(data,){
         console.log(data[1])
})

$(ALL).click(function(){
      for(let i=0;i<250;i++){
        let Ndiv=document.createElement("div");
        Ndiv.className="Ndiv"
      
        $.get("https://restcountries.eu/rest/v2/all?fields=name;capital;currencies;topLevelDomain;flag", function(data){
          $(Ndiv).append( `Name is: ${data[i].name} <br>Capital is: ${data[i].capital} <br> Neme of currencies is: ${data[i].currencies[0].name}  <br> The top Level Domain is: ${data[i].topLevelDomain} <img src=${data[i].flag} class="img"  >` )

          $(div).append(Ndiv);

        });
      } 
  });

  $(Search).click(function(){

    let country=input.value
    if(country==""){
      alert("הכנס שם מדינה")
    }
    let Ndiv2=document.createElement("div");
       Ndiv2.className="Ndiv"
    $.get(`https://restcountries.eu/rest/v2/name/${country}?fields=name;capital;currencies;topLevelDomain;flag`,function(data){
      $(Ndiv2).append( `Name is: ${data[0].name} <br>Capital is: ${data[0].capital} <br> Neme of currencies is:${data[0].currencies[0].name }  <br> The top Level Domain is: ${data[0].topLevelDomain} <img src=${data[0].flag} class="img"  >` )
      $(div).append(Ndiv2);
   
  })
})  
