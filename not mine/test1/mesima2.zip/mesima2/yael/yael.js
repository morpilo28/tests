
let Radius = document.querySelector("#canvas");
console.log(Radius)
let ctx = Radius.getContext("2d");

let radiusELM = document.querySelector("#radius")
let volumeELM = document.querySelector("#volume")
let buttonBTN = document.querySelector("#button")
let clearCanvasBTN = document.querySelector("#cleanCanvas")
let BonusBTN = document.querySelector("#Bonus")


let Radius = radiusELM.value

buttonBTN.addEventListener("click",function(){
    let Radius = radiusELM.value
    console.log(Radius);
    if (isNaN(Number)(Radius)){
        alert("It is not a number./nEnter only a numeric value!!") 
    }else if(Number(Radius)<0){
        alert("A number less than 0 will not work within a radius./nEnter only positive number!!")
    }else{Radius = Number(Radius)
    
    volumeELM.value = Volume(Radius)
    }
    drow(Radius)
})
function Volume(Radius){
  return  4 * Math.PI * Math.pow (Radius * Radius * Radius) / 3;
}


function clearCanvas(){
    ctx.clearRect(0, 0, 450, 450);
}
clearCanvasBTN.addEventListener("click",  clearCanvas);




function max(){
    if (canvas.width >= canvas.height)
    return canvas.width/2
    else if (canvas.height >= canvas.width) 
    return canvas.height/2
}


function drow(Radius){
    ctx.beginPath();
    ctx.strokeStyle = "green";
    ctx.arc(canvas.width/2,canvas.height/2, Radius, 0 ,2 * Math.PI);
    ctx.stroke();  
}


function Bonus(){
    for (let i = 0 ; i <= max() ; i++)
    
    setTimeout(function() {100});
      
    drow(i)
} 
BonusBTN.addEventListener("click", function(){
    drow(i)
})();